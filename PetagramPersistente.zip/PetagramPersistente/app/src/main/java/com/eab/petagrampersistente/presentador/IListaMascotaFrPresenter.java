package com.eab.petagrampersistente.presentador;

public interface IListaMascotaFrPresenter {
    public void obtenerListaMascotas();
    public void mostrarMascotasRV();
}
