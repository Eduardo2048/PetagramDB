package com.eab.petagrampersistente.presentador;

public interface IMasBuscadosPresenter {
    public void obtenerListaMasBuscados();
    public void mostrarMasBuscadosRV();
}
