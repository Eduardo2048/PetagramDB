package com.eab.petagrampersistente;

public class DB {
}
