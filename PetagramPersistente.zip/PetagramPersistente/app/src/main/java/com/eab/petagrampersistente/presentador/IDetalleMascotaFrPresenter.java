package com.eab.petagrampersistente.presentador;

public interface IDetalleMascotaFrPresenter {
    public void obtenerDetalleMascota();
    public void mostrarDetalleMascotasRV();
}
